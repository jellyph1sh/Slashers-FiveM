local isStart = false
local radio = nil
local jerrycan = false
local generator = nil
local police = false
local radar = false
local infiteStamina = false
local nightvision = false
local nv = false
local killer = false
local jerrycanNumber = 0

RegisterNetEvent('slashers:allowed')
AddEventHandler('slashers:allowed', function(args)
    if args == 'start' then
        TriggerServerEvent('slashers:start')
    elseif args == 'stop' then
        TriggerServerEvent('slashers:stop')
    else
        TriggerEvent('chatMessage', '[ERROR]', {255,0,0}, 'Argument Invalid!')
    end
end)

RegisterNetEvent('slashers:startdenied')
AddEventHandler('slashers:startdenied', function()
    TriggerEvent('chatMessage', '[ERROR]', {255,0,0}, 'Un mini-jeu est déjà en cours!')
end)

RegisterNetEvent('slashers:getmodel')
AddEventHandler('slashers:getmodel', function(hash)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Citizen.Wait(1)
    end
end)

RegisterNetEvent('slashers:setplayer')
AddEventHandler('slashers:setplayer', function(ped, pos)
    radar = false
    hash = GetHashKey(Config.Peds[ped].model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Wait(0)
    end
    SetPlayerModel(PlayerId(), hash)
    if ped ~= #Config.Peds then
        TriggerEvent('game:godmode', false)
        SetEntityHealth(GetPlayerPed(-1), 135)
        SetFollowPedCamViewMode(4)
        isStart = true
    else
        TriggerEvent('game:godmode', true)
        SetFollowPedCamViewMode(1)
        SetNightvision(false)
        isStart = false
        radio = nil
        jerrycan = false
        generator = nil
        police = false
        radar = false
        infiteStamina = false
        nightvision = false
        nv = false
        killer = false
        jerrycanNumber = 0
    end
    SetModelAsNoLongerNeeded(hash)
    SetEntityCoords(GetPlayerPed(-1), Config.Peds[ped].coords[pos].x, Config.Peds[ped].coords[pos].y, Config.Peds[ped].coords[pos].z, true, false, false, false)
    SetEntityHeading(GetPlayerPed(-1), Config.Peds[ped].coords[pos].w)
    NetworkSetFriendlyFireOption(false)
    SetCanAttackFriendly(PlayerPedId(), false, false)
    if Config.Peds[ped].capacity == Config.Peds[1].capacity then
        infiteStamina = true
    elseif Config.Peds[ped].capacity == Config.Peds[2].capacity then
        SetEntityHealth(GetPlayerPed(-1), 200)
    elseif Config.Peds[ped].capacity == Config.Peds[3].capacity then
        radar = true
    elseif Config.Peds[ped].capacity == Config.Peds[4].capacity then
        nightvision = true
    elseif Config.Peds[ped].capacity == Config.Peds[5].capacity then
        GiveWeaponToPed(GetPlayerPed(-1), GetHashKey('weapon_revolver'), 18, false, true)
        NetworkSetFriendlyFireOption(true)
        SetCanAttackFriendly(PlayerPedId(), true, true)
    elseif Config.Peds[ped].capacity == Config.Peds[6].capacity then
        SetEntityHealth(GetPlayerPed(-1), 200)
        GiveWeaponToPed(GetPlayerPed(-1), GetHashKey('weapon_machete'), 18, false, true)
        killer = true
        NetworkSetFriendlyFireOption(true)
        SetCanAttackFriendly(PlayerPedId(), true, true)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isStart then
            SetPlayerHealthRechargeMultiplier(GetPlayerPed(-1), 0.0)
            SetFollowPedCamViewMode(4)
            HideHudComponentThisFrame(14)
            HideAreaAndVehicleNameThisFrame()
        end
        if not radar and isStart then
            HideHudAndRadarThisFrame()
        end
        if radar then
            local players = GetPlayersClient()
            for k, player in pairs(players) do
                if GetPlayerPed(player) ~= GetPlayerPed(-1) then
                    ped = GetPlayerPed(player)
                    blip = GetBlipFromEntity(ped)
                    if not DoesBlipExist(blip) then
                        blip = AddBlipForEntity(ped)
                        SetBlipSprite(blip, 1)
                        SetBlipColour(blip, 38)
                        SetBlipDisplay(blip, 6)
                        SetBlipScale(blip, 0.8)
                        SetBlipFlashes(blip, true)
                        SetBlipFlashInterval(blip, 750)
                        BeginTextCommandSetBlipName('STRING')
                        AddTextComponentString('Entité en mouvement')
                        EndTextCommandSetBlipName(blip)
                    end
                end
            end
        elseif infiteStamina then
            RestorePlayerStamina(PlayerId(), 1.0)
            SetRunSprintMultiplierForPlayer(PlayerId(), 1.10)
        elseif nightvision then
            if nv then
                helpNotification('Appuyez ~INPUT_DETONATE~ pour désactiver la vision nocturne')
            else
                helpNotification('Appuyez ~INPUT_DETONATE~ pour activer la vision nocturne')
            end
            if IsControlJustReleased(1, Config.ControlNv) then
                if nv then
                    nv = false
                    SetNightvision(nv)
                else
                    nv = true
                    SetNightvision(nv)
                end
            end
        elseif killer then
            if HasEntityBeenDamagedByAnyPed(GetPlayerPed(-1)) then
                SetPedIsDrunk(GetPlayerPed(-1), true)
                Wait(2000)
                SetPedIsDrunk(GetPlayerPed(-1), false)
            end
            RestorePlayerStamina(PlayerId(), 1.0)
            SetEntityInvincible(GetPlayerPed(-1), true)
            SetPlayerInvincible(PlayerId(), true)
            ClearPedBloodDamage(GetPlayerPed(-1))
            ResetPedVisibleDamage(GetPlayerPed(-1))
            ClearPedLastWeaponDamage(GetPlayerPed(-1))
            SetEntityProofs(GetPlayerPed(-1), true, true, true, true, true, true, true, true)
            SetEntityOnlyDamagedByPlayer(GetPlayerPed(-1), false)
            SetEntityCanBeDamaged(GetPlayerPed(-1), false)
        end
    end
end)

RegisterNetEvent('slashers:removeobjects')
AddEventHandler('slashers:removeobjects', function(object)
    for k, object in pairs(Config.Objects) do
        for k, pos in pairs(object.coords) do
            local object = GetClosestObjectOfType(pos.x, pos.y, pos.z, object.radius, GetHashKey(object.model), true, false, false)
            DeleteObject(object)
        end
    end
end)

RegisterNetEvent('slashers:deleteobject')
AddEventHandler('slashers:deleteobject', function(x, y, z)
    local object = GetClosestObjectOfType(x, y, z, 5.0, GetHashKey('w_am_jerrycan'), true, false, false)
    DeleteObject(object)
    local pos = Config.Vehicles.coords
    local vehicle = GetClosestVehicle(pos.x, pos.y, pos.z, 5.0, hash)
    DeleteVehicle(vehicle)
end)

RegisterNetEvent('slashers:jerrycanNumber')
AddEventHandler('slashers:jerrycanNumber', function(numb)
    jerrycanNumber = numb
end)

RegisterNetEvent('slashers:generator')
AddEventHandler('slashers:generator', function(bool)
    generator = bool
end)

RegisterNetEvent('slashers:radio')
AddEventHandler('slashers:radio', function(bool)
    radio = bool
end)

RegisterNetEvent('slashers:police')
AddEventHandler('slashers:police', function()
    local players = GetPlayers()
    local hash = GetHashKey(Config.Vehicles.model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Citizen.Wait(1)
    end
    for k, player in pairs(players) do
        TriggerEvent('slashers:getmodel', player, hash)
    end
    local coords = Config.Vehicles.coords
    for k, pos in pairs(coords) do
        local vehicle = CreateVehicle(hash, pos.x, pos.y, pos.z, pos.w, true, true)
        SetEntityAsMissionEntity(vehicle, true, true)
        SetEntityAsNoLongerNeeded(vehicle)
        SetModelAsNoLongerNeeded(vehicle)
        SetVehicleDoorsLocked(vehicle, 2)
        SetVehicleEngineOn(vehicle, true)
        SetVehicleUndriveable(vehicle, true)
        SetVehicleDirtLevel(vehicle, 2.0)
        SetVehicleDoorsLocked(vehicle, 2)
        SetVehicleExtra(vehicle, 7, 1)
        SetVehicleSiren(vehicle, true)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if not killer then
            for k, object in pairs(Config.Objects) do
                for k, pos in pairs(object.coords) do
                    local ply = GetPlayerPed(-1)
                    local plyCoords = GetEntityCoords(ply, true)
                    local distance = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.x, pos.y, pos.z)
                    if distance <= Config.DrawDistance then
                        local target = GetClosestObjectOfType(pos.x, pos.y, pos.z, object.radius, GetHashKey(object.model), true, false, false)
                        if DoesEntityExist(target) then
                            if GetEntityModel(target) == GetHashKey('prop_radio_01') then
                                if radio then
                                    Draw3DText(pos.x, pos.y, pos.z + 0.25, 'Radio ~g~allumée')
                                elseif radio == nil then
                                    Draw3DText(pos.x, pos.y, pos.z + 0.25, '~r~Pas de courant')
                                elseif not radio then
                                    Draw3DText(pos.x, pos.y, pos.z + 0.25, '[E] Radio ~r~éteinte')
                                end
                            elseif GetEntityModel(target) == GetHashKey('w_am_jerrycan') then
                                if jerrycanNumber == 3 then
                                    Draw3DText(pos.x, pos.y, pos.z + 0.25, '~r~Non nécessaire')
                                else
                                    Draw3DText(pos.x, pos.y, pos.z + 0.25, '[E] ~g~Prendre')
                                end
                            elseif GetEntityModel(target) == GetHashKey('prop_elecbox_07a') then
                                if generator then
                                    Draw3DText(pos.x, pos.y, pos.z + 1.0, '~g~Activé')
                                elseif generator == false then
                                    Draw3DText(pos.x, pos.y, pos.z + 1.0, '[E] ~g~Activer')
                                elseif generator == nil and jerrycanNumber < 3 then
                                    local need = 3 - jerrycanNumber
                                    Draw3DText(pos.x, pos.y, pos.z + 1.0, 'Besoin de ~r~'..need..' jerrycans')
                                end
                            end
                            if IsControlJustPressed(1, Config.Control) then
                                if GetEntityModel(target) == GetHashKey('prop_radio_01') then
                                    if radio ~= nil then
                                        if not radio then
                                            TriggerServerEvent('slashers:activeobject', 'radio')
                                        end
                                    end
                                elseif GetEntityModel(target) == GetHashKey('w_am_jerrycan') then
                                    if jerrycanNumber < 3 then
                                        TriggerServerEvent('slashers:activeobject', 'jerrycan')
                                    end
                                elseif GetEntityModel(target) == GetHashKey('prop_elecbox_07a') then
                                    if generator ~= nil then
                                        if generator == false then
                                            TriggerServerEvent('slashers:activeobject', 'generator')
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)