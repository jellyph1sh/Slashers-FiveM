fx_version 'cerulean'
game 'gta5'

author 'Time_XP'
description 'Game for server event'
version '1.0.0'

client_scripts {
    'client/functions.lua',
    'client/main.lua'
}
server_script 'server.lua'
shared_script 'config.lua'