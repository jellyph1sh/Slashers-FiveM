local isStart = false
local radio = nil
local generator = nil
local jerrycan = false
local jerrycanNumber = 0

local function spawnObject()
    for k, object in pairs(Config.Objects) do
        hash = GetHashKey(object.model)
        local players = GetPlayers()
        for k, v in pairs(players) do
            TriggerClientEvent('slashers:getmodel', v, hash)
        end
        for k, pos in pairs(object.coords) do
            local object = CreateObject(hash, pos.x, pos.y, pos.z, true, true, false)
        end
    end
end

RegisterServerEvent('slashers:start')
AddEventHandler('slashers:start', function()
    if not isStart then
        isStart = true
        local numbers = {1, 2, 3, 4, 5, 6}
        local players = GetPlayers()
        for k, player in pairs(players) do
            local random = numbers[math.random(#numbers)]
            table.remove(numbers, random)
            local spawnPoint = math.random(1, 2)
            TriggerClientEvent('slashers:setplayer', player, random, spawnPoint)
        end
        Citizen.Wait(1000)
        spawnObject()
    else
        TriggerClientEvent('slashers:startdenied', source)
    end
end)

RegisterServerEvent('slashers:stop')
AddEventHandler('slashers:stop', function()
    isStart = false
    local players = GetPlayers()
    for k, v in pairs(players) do
        TriggerClientEvent('slashers:removeobjects', v)
        TriggerClientEvent('slashers:setplayer', v, #Config.Peds, 1)
    end
    isStart = false
    radio = nil
    generator = nil
    jerrycan = false
    jerrycanNumber = 0
end)

RegisterServerEvent('slashers:activeobject')
AddEventHandler('slashers:activeobject', function(object)
    local players = GetPlayers()
    if object == 'jerrycan' then
        if jerrycanNumber < 3 then
            jerrycanNumber = jerrycanNumber + 1
            local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(source)))
            for k, v in pairs(players) do
                TriggerClientEvent('slashers:deleteobject', v, x, y, z)
                TriggerClientEvent('slashers:jerrycanNumber', v, jerrycanNumber)
            end
        end
        if jerrycanNumber == 3 then
            generator = false
            for k, v in pairs(players) do
                TriggerClientEvent('slashers:generator', v, generator)
            end
        end
    elseif object == 'generator' then
        if not generator then
            generator = true
            for k, v in pairs(players) do
                TriggerClientEvent('slashers:generator', v, generator)
            end
            if generator then
                radio = false
                for k, v in pairs(players) do
                    TriggerClientEvent('slashers:radio', v, radio)
                end
            end
        end
    elseif object == 'radio' then
        if not radio then
            radio = true
            for k, v in pairs(players) do
                TriggerClientEvent('slashers:radio', v, radio)
                Wait(1000)
                TriggerClientEvent('slashers:police', v)
            end
        end
    end
end)