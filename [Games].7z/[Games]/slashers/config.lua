Config = {}

--[[

    Peds :
        - Sportif : a_m_m_beach_01
        - Résistant : a_m_m_genfat_02
        - Radar : a_m_y_vinewood_02
        - VN : cs_hunter
        - Pistol : Ranger01SFY
        - Killer : ig_orleans
        - Policeman : s_m_y_cop_01

    Objects :
        - Jerrycan : w_am_jerrycan
        - Generator : prop_generator_04
        - Radio : prop_radio_01
    Weapons :
        - Killer : weapon_stone_hatchet
        - Pistol : weapon_heavy_revolver
    Vehicules : 
        - Police vehicule : sheriff

]]--

Config.DrawDistance = 1.5
Config.Control = 38
Config.ControlNv = 47

Config.Peds = {
    {
        model = 'a_m_y_breakdance_01',
        coords = {
            vector4(-1063.813, 4970.128, 208.839, 136.102),
            vector4(-1068.719, 4893.101, 214.271, 0.692)
        },
        capacity = 'athletic'
    },
    {
        model = 'a_m_m_genfat_02',
        coords = {
            vector4(-1100.58, 4946.14, 218.324, 61.245),
            vector4(-1141.17, 4965.132, 221.343, 342.342)
        },
        capacity = 'resistant'
    },
    {
        model = 'a_m_y_vinewood_02',
        coords = {
            vector4(-1154.146, 4896.0, 218.919, 121.478),
            vector4(-1102.389, 4861.036, 215.66, 350.51)
        },
        capacity = 'radar'
    },
    {
        model = 'ig_hunter',
        coords = {
            vector4(-1105.902, 4916.909, 216.819, 52.861),
            vector4(-1081.103, 4940.785, 229.222, 358.591)
        },
        capacity = 'nightvision'
    },
    {
        model = 's_f_y_ranger_01',
        coords = {
            vector4(-1105.353, 4880.154, 216.067, 323.006),
            vector4(-1150.494, 4940.623, 222.269, 248.008)
        },
        capacity = 'sherrif'
    },
    {
        model = 'g_m_m_chicold_01',
        coords = {
            vector4(-1043.569, 4910.9, 208.508, 112.283),
            vector4(-1179.551, 4928.21, 223.334, 70.402)
        },
        capacity = 'killer'
    },
    {
        model = 'u_m_y_rsranger_01',
        coords = {
            vector4(-2138.266, 3271.846, 32.810, 0.0)
        },
    }
}

Config.Objects = {
    Jerrycan = {
        model = 'w_am_jerrycan',
        coords = {
            vector3(-1122.215, 4894.465, 217.472),
            vector3(-1138.972, 4910.716, 219.969),
            vector3(-1111.503, 4897.823, 217.595),
            vector3(-1118.649, 4908.678, 217.595),
            vector3(-1062.273, 4966.723, 208.425)
        },
        radius = 2.0
    },
    Generator = {
        model = 'prop_elecbox_07a',
        coords = {
            vector3(-1133.339, 4961.249, 221.243),
            vector3(-1102.971, 4880.416, 215.067),
            vector3(-1117.292, 4904.203, 217.596),
            vector3(-1135.486, 4904.712, 219.969)
        }, 
        radius = 2.0
    },
    Radio = {
        model = 'prop_radio_01',
        coords = {
            vector3(-1095.393, 4888.307, 215.911),
            vector3(-1081.618, 4894.589, 213.979),
            vector3(-1138.203, 4959.887, 222.08)
        },
        radius = 2.0
    }
}
   
Config.Police = {
    model = 's_m_y_sheriff_01',
    coords = {
        vector4(-1034.994, 4916.808, 205.244, 119.042),
        vector4(-1033.177, 4912.601, 205.585, 97.307)
    }
}

Config.Vehicles = {
    model = 'sheriff',
    coords = {
        vector4(-1038.488, 4914.605, 206.791, 210.042),
        vector4(-1035.669, 4910.695, 206.791, 345.356)
    }
}